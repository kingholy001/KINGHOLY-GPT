import 'dotenv/config';
import express from 'express';
import OpenAI from 'openai';
const app=express();
app.use(express.json({limit:'12mb'}));
app.use(express.static('public'));
const ai=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
const identity='You are KINGHOLY-GPT, a helpful, creative and honest AI assistant. You can explain, code, tutor and create detailed image prompts. Do not claim to have done things you have not done. Follow safety guidelines.';
app.post('/api/chat',async(req,res)=>{
 try{
  const {message,history=[],image}=req.body;
  if(typeof message!=='string'||message.length>12000||!Array.isArray(history))return res.status(400).json({error:'Invalid message'});
  const prior=history.slice(-12).filter(x=>['user','assistant'].includes(x.role)&&typeof x.content==='string').map(x=>({role:x.role,content:x.content.slice(0,12000)}));
  const content=[{type:'input_text',text:message||'Describe this image'}];
  if(image){if(typeof image!=='string'||!/^data:image\/(png|jpeg|webp);base64,/.test(image)||image.length>9000000)return res.status(400).json({error:'Invalid image'});content.push({type:'input_image',image_url:image});}
  const response=await ai.responses.create({model:'gpt-4.1-mini',instructions:identity,input:[...prior,{role:'user',content}]});
  res.json({reply:response.output_text||'No text returned.'});
 }catch(e){console.error(e);res.status(500).json({error:'AI request failed. Check server settings and API access.'});}
});
app.post('/api/image',async(req,res)=>{
 try{
  const {prompt}=req.body;
  if(typeof prompt!=='string'||!prompt.trim()||prompt.length>4000)return res.status(400).json({error:'Invalid prompt'});
  const response=await ai.images.generate({model:'gpt-image-1-mini',prompt,size:'1024x1024'});
  res.json({image:'data:image/png;base64,'+response.data[0].b64_json});
 }catch(e){console.error(e);res.status(500).json({error:'Image generation failed. Check model access and billing.'});}
});
app.listen(process.env.PORT||3000,()=>console.log('KINGHOLY-GPT is running'));
