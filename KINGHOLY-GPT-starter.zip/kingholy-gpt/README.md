# KINGHOLY-GPT starter

Includes glowing mobile-friendly UI, chat with recent conversation context, image understanding via upload, prompt maker, image generation and image download. Chat history is session-only. This is a starter, not a full ChatGPT clone; it needs an OpenAI API account with access and billing enabled. Do not publish this demo as a public service without authentication, rate limits, abuse controls, and usage budgets.

## Setup
1. Install Node.js 20+ on a computer or compatible development environment.
2. Open a terminal in this folder and run `npm install`.
3. Copy `.env.example` to `.env`, and replace the placeholder with your own private API key. Never place the key in `public/index.html` or commit `.env`.
4. Run `npm start`.
5. Open `http://localhost:3000` in your browser.

Model access, image-generation eligibility and charges depend on your API account. If needed, adjust model IDs in server.js to models enabled for your account. Do not host this as a static-only website: the Node server is required.
